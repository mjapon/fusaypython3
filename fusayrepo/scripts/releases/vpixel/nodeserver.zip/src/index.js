const express = require('express')
const app = express();
const http = require('http');
const server = http.Server(app);
const socketIO = require('socket.io');

const io = socketIO(server, {
  cors: {
    origin: "http://192.168.0.116:4200",
    //headers: 'Content-Type, Authorization',
    methods: ["GET", "POST"],
    credentials: true   
  }
});

const port = process.env.PORT || 3000;
io.on('connection', (socket) => {
    console.log('Nuevo usuario conectado-->');
    io.emit('new-pixel', {msg:'Nuevo usuario conectado:'+socket.id, tipo:0});

    socket.on('disconnect', function(){
    	console.log('<--Usuario desconectado');
    	io.emit('new-pixel', {msg:'Usuario desconectado:'+socket.id, tipo:1});
   	});
   	
   	socket.on('new-message', function(message){
   		io.emit('new-pixel', {msg:message, tipo:2});
   	});

});

server.listen(port, () => {
    console.log(`Servidor iniciado en el puerto: ${port}`);
});