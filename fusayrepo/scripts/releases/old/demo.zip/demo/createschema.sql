create schema demo;

SET search_path TO demo;








